using Godot;
using System;

public partial class SetVolume : AudioStreamPlayer{

    [Export] private AudioStreamPlayer delayedPlayer;

    public override void _Ready() {
        base._Ready();

        GD.Print("Setting volume to NaN number");

        // Setting VolumeDb to a NaN
        VolumeDb = Mathf.LinearToDb(-0.1f); // This returns NaN

        GD.Print("VolumeDb is: ", VolumeDb );

        GD.Print("Playing after setting invalid volume");

        // Play the sound, doesn't work.
        Play();

        GD.Print("Waiting 3 seconds to play a different AudioStreamPlayer...");

        var delayTimer = GetTree().CreateTimer(3f);

        delayTimer.Timeout += () => {

            GD.Print("Playing a different AudioStreamPlayer");

            // Playing a different player doesn't work either
            delayedPlayer.Play();

        };
    }

}
